package com.zhongxing.test;

public interface Test1  {
	void c();
	String b();
}
