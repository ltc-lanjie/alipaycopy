package com.zhongxing.test;

public interface Person {
	 void a();
	 String b();
}
