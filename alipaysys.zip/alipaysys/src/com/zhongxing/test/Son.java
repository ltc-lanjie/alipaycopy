package com.zhongxing.test;

public class Son implements Person {

	@Override
	public void a() {
		System.out.println("这是子类的a");

	}

	@Override
	public String b() {
		// TODO Auto-generated method stub
		return "b";
	}

}
